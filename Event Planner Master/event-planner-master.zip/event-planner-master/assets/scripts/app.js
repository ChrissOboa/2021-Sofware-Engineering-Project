'use strict';

const app = {
  host: 'http://localhost:3000',
};

module.exports = app;
